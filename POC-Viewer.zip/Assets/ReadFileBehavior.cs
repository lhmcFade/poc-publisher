using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class ReadFileBehavior : MonoBehaviour
{

    public TMP_InputField text;
    private Button button;

    void Awake()
    {
        this.button = GetComponent<Button>();
        this.button.onClick.AddListener(ReadFile);
    }

    private void ReadFile()
    {
        string content = null;
        try
        {
            content = File.ReadAllText("c:/teste.txt");
        }
        catch (Exception e)
        {

            content = $"Error reading file. Reason: \n {e.Message}";
        }

        text.text = content;
    }

}
